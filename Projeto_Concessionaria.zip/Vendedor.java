//João Pedro Aleksandrov Lorenzetti

public class Vendedor extends Pessoa {
    private int idVendedor;
    private double comissao;
    private int vendasRealizadas;

    public Vendedor(String nome, String cpf, String telefone, int idVendedor, double comissao) {
        super(nome, cpf, telefone);
        this.idVendedor = idVendedor;
        this.comissao = comissao;
        this.vendasRealizadas = 0;
    }

    @Override
    public void exibirInformacoes() {
        System.out.println("\n--- Informações do Vendedor ---");
        System.out.println("ID: " + idVendedor);
        System.out.println("Nome: " + nome);
        System.out.println("CPF: " + cpf);
        System.out.println("Telefone: " + telefone);
        System.out.println("Comissão: " + (comissao * 100) + "%");
        System.out.println("Vendas Realizadas: " + vendasRealizadas);
    }

    public void registrarVenda(double valorVenda) {
        vendasRealizadas++;
        System.out.println("Venda registrada para " + nome +". Comissão: R$" + (valorVenda * comissao));
    }

     public void setIdVendedor(int idVendedor) {
        if (idVendedor <= 0) {
            throw new IllegalArgumentException("ID do vendedor deve ser positivo!");
        }
        this.idVendedor = idVendedor;
    }

    public void setComissao(double comissao) {
        if (comissao < 0 || comissao > 0.15) { 
            throw new IllegalArgumentException("Comissão inválida! Deve estar entre 0 e 15%");
        }
        this.comissao = comissao;
    }

    public void incrementarVendasRealizadas() {
        this.vendasRealizadas++;
    }

    public int getIdVendedor() { 
        return idVendedor; 
    }
    public double getComissao() { 
        return comissao; 
    }
    public int getVendasRealizadas() { 
        return vendasRealizadas; 
    }
}