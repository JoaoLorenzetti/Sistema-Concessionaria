//João Pedro Aleksandrov Lorenzetti

public interface Vendavel {
    double calcularPrecoVenda();
    void exibirDetalhes();
}