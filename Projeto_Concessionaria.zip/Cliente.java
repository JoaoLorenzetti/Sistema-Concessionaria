//João Pedro Aleksandrov Lorenzetti

public class Cliente extends Pessoa {
    private String endereco;
    private boolean clientePremium;

    public Cliente(String nome, String cpf, String telefone, String endereco, boolean clientePremium) {
        super(nome, cpf, telefone);
        this.endereco = endereco;
        this.clientePremium = clientePremium;
    }

    @Override
    public void exibirInformacoes() {
        System.out.println("\n--- Informações do Cliente ---");
        System.out.println("Nome: " + nome);
        System.out.println("CPF: " + cpf);
        System.out.println("Telefone: " + telefone);
        System.out.println("Endereço: " + endereco);
        System.out.println("Cliente Premium: " + (clientePremium ? "Sim" : "Não"));
    }

     public void setEndereco(String endereco) {
        if (endereco == null || endereco.trim().isEmpty()) {
            throw new IllegalArgumentException("Endereço não pode ser vazio!");
        }
        this.endereco = endereco;
    }

    public void setClientePremium(boolean clientePremium) {
        this.clientePremium = clientePremium;
    }

    public String getEndereco() { 
        return endereco; 
    }
    public boolean isClientePremium() { 
        return clientePremium; 
    }
}