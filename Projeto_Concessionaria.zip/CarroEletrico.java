//João Pedro Aleksandrov Lorenzetti

public class CarroEletrico extends Carro {
    private int autonomia;
    private int tempoRecarga;

    public CarroEletrico(String modelo, String marca, int ano, double precoBase, 
                         String placa, int autonomia, int tempoRecarga) {
        super(modelo, marca, ano, precoBase, placa);
        this.autonomia = autonomia;
        this.tempoRecarga = tempoRecarga;
    }

     public int getAutonomia() {
        return autonomia;
    }

    public int getTempoRecarga() {
        return tempoRecarga;
    }

    public void setAutonomia(int autonomia) {
        if (autonomia <= 0) {
            throw new IllegalArgumentException("Autonomia deve ser positiva!");
        }
        this.autonomia = autonomia;
    }

    public void setTempoRecarga(int tempoRecarga) {
        if (tempoRecarga <= 0) {
            throw new IllegalArgumentException("Tempo de recarga deve ser positivo!");
        }
        this.tempoRecarga = tempoRecarga;
    }

    //Sobrescrita
    @Override
    public double calcularPrecoVenda() {
        double preco = precoBase * 1.15;
        if (autonomia > 400) {
            preco += 10000;
        }
        return preco;
    }

    //Sobrescrita
    @Override
    public void exibirDetalhes() {
        super.exibirDetalhes();
        System.out.println("Tipo: Elétrico");
        System.out.println("Autonomia: " + autonomia + " km");
        System.out.println("Tempo de Recarga: " + tempoRecarga + " horas");
        System.out.println("Preço de Venda: R$" + calcularPrecoVenda());
    }
}