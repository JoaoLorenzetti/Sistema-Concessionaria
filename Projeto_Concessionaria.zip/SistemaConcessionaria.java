//João Pedro Aleksandrov Lorenzetti

public class SistemaConcessionaria {
    public static void main(String[] args) {
        Concessionaria concessionaria = new Concessionaria("AutoLux", "Av. Principal, 123");

        concessionaria.cadastrarVendedor(
            new Vendedor("João Silva", "111.222.333-44", "(43) 9999-8888", 1, 0.05));
        concessionaria.cadastrarVendedor(
            new Vendedor("Maria Santos", "555.666.777-88", "(43) 9777-6666", 2, 0.07));

        concessionaria.cadastrarCliente(
            new Cliente("Carlos Oliveira", "999.888.777-66", "(43) 9555-4444", 
                       "Rua das Flores, 100", true));
        concessionaria.cadastrarCliente(
            new Cliente("Ana Pereira", "444.333.222-11", "(43) 9333-2222", 
                       "Av. Paulista, 900", false));

        concessionaria.cadastrarCarro(
            new CarroEsportivo("911 Turbo", "Porsche", 2023, 800000, "ABC-1234", 320, true));
        concessionaria.cadastrarCarro(
            new CarroLuxo("S-Class", "Mercedes", 2023, 1200000, "XYZ-5678", true, true));
        concessionaria.cadastrarCarro(
            new CarroEletrico("Model S", "Tesla", 2023, 650000, "ELT-4321", 600, 8));

        concessionaria.listarVendedores();
        concessionaria.listarClientes();

        System.out.println("\n=== Realizando Vendas ===");
        concessionaria.realizarVenda("ABC-1234", "999.888.777-66", 1, "Cartão de Crédito", 10000);
        concessionaria.realizarVenda("XYZ-5678", "444.333.222-11", 2, "Financiamento", 20000);

        concessionaria.listarVendas();
   
        //Reflexividade
        concessionaria.demonstrarReflexividade();

    }
}