//João Pedro Aleksandrov Lorenzetti

public class CarroLuxo extends Carro {
    private boolean temRevestimentoCouro;
    private boolean temSistemaSomPremium;

    public CarroLuxo(String modelo, String marca, int ano, double precoBase, 
                     String placa, boolean temRevestimentoCouro, boolean temSistemaSomPremium) {
        super(modelo, marca, ano, precoBase, placa);
        this.temRevestimentoCouro = temRevestimentoCouro;
        this.temSistemaSomPremium = temSistemaSomPremium;
    }

    public boolean isTemRevestimentoCouro() {
        return temRevestimentoCouro;
    }

    public boolean isTemSistemaSomPremium() {
        return temSistemaSomPremium;
    }

    public void setTemRevestimentoCouro(boolean temRevestimentoCouro) {
        this.temRevestimentoCouro = temRevestimentoCouro;
    }

    public void setTemSistemaSomPremium(boolean temSistemaSomPremium) {
        this.temSistemaSomPremium = temSistemaSomPremium;
    }

    //Sobrescrita
    @Override
    public double calcularPrecoVenda() {
        double preco = precoBase * 1.30;
        if (temRevestimentoCouro) {
            preco += 10000;
        }
        if (temSistemaSomPremium) {
            preco += 8000;
        }
        return preco;
    }

    //Sobrescrita
    @Override
    public void exibirDetalhes() {
        super.exibirDetalhes();
        System.out.println("Tipo: Luxo");
        System.out.println("Revestimento em Couro: " + (temRevestimentoCouro ? "Sim" : "Não"));
        System.out.println("Sistema de Som Premium: " + (temSistemaSomPremium ? "Sim" : "Não"));
        System.out.println("Preço de Venda: R$" + calcularPrecoVenda());
    }
}