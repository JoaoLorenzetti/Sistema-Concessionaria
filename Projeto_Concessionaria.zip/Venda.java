//João Pedro Aleksandrov Lorenzetti

import java.time.LocalDate;

public class Venda {
    private Carro carro;
    private Cliente cliente;
    private Vendedor vendedor;
    private LocalDate dataVenda;
    private double valorFinal;
    private String formaPagamento;

    public Venda(Carro carro, Cliente cliente, Vendedor vendedor, 
                 double valorFinal, String formaPagamento) {
        this.carro = carro;
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.dataVenda = LocalDate.now();
        this.valorFinal = valorFinal;
        this.formaPagamento = formaPagamento;
    }

    public void exibirRecibo() {
        System.out.println("\n=== RECIBO DE VENDA ===");
        System.out.println("Data: " + dataVenda);
        System.out.println("\nDados do Carro:");
        carro.exibirDetalhes();
        System.out.println("\nDados do Cliente:");
        cliente.exibirInformacoes();
        System.out.println("\nDados do Vendedor:");
        vendedor.exibirInformacoes();
        System.out.println("\nValor Final: R$" + valorFinal);
        System.out.println("Forma de Pagamento: " + formaPagamento);
        System.out.println("=======================");
    }

     public void setValorFinal(double valorFinal) {
        if (valorFinal <= 0) {
            throw new IllegalArgumentException("Valor final deve ser positivo!");
        }
        this.valorFinal = valorFinal;
    }

    public void setFormaPagamento(String formaPagamento) {
        if (!formaPagamento.matches("À vista|Cartão|Financiamento|Pix")) {
            throw new IllegalArgumentException("Forma de pagamento inválida!");
        }
        this.formaPagamento = formaPagamento;
    }

    public Carro getCarro() {
         return carro; 
    }
    public Cliente getCliente() { 
        return cliente; 
    }
    public Vendedor getVendedor() { 
        return vendedor;
    }
    public LocalDate getDataVenda() {
         return dataVenda; 
    }
    public double getValorFinal() { 
        return valorFinal; 
    }
    public String getFormaPagamento() { 
        return formaPagamento; 
    }
}