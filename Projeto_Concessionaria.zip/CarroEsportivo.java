//João Pedro Aleksandrov Lorenzetti

public class CarroEsportivo extends Carro {
    private double velocidadeMaxima;
    private boolean turbo;

    public CarroEsportivo(String modelo, String marca, int ano, double precoBase, 
                          String placa, double velocidadeMaxima, boolean turbo) {
        super(modelo, marca, ano, precoBase, placa); 
        this.velocidadeMaxima = velocidadeMaxima;
        this.turbo = turbo;
    }

    public double getVelocidadeMaxima() {
        return velocidadeMaxima;
    }

    public boolean isTurbo() { 
        return turbo;
    }

    public void setVelocidadeMaxima(double velocidadeMaxima) {
        if (velocidadeMaxima <= 0) {
            throw new IllegalArgumentException("Velocidade deve ser positiva!");
        }
        this.velocidadeMaxima = velocidadeMaxima;
    }

    public void setTurbo(boolean turbo) {
        this.turbo = turbo;
    }

    //Sobrescrita
    @Override
    public double calcularPrecoVenda() {
        double preco = precoBase * 1.20;
        if (turbo) preco += 15000;
        return preco;
    }

    //Sobrescrita
    @Override
    public void exibirDetalhes() {
        super.exibirDetalhes(); 
        System.out.println("Tipo: Esportivo");
        System.out.println("Velocidade Máxima: " + velocidadeMaxima + " km/h");
        System.out.println("Turbo: " + (turbo ? "Sim" : "Não"));
    }
}