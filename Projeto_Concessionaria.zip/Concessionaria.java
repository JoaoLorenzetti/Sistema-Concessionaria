//João Pedro Aleksandrov Lorenzetti

import java.util.ArrayList;
import java.util.List;

public class Concessionaria {
    private String nome;
    private String endereco;
    private List<Carro> carros;
    private List<Vendedor> vendedores;
    private List<Cliente> clientes;
    private List<Venda> vendas;

    public Concessionaria(String nome, String endereco) {
        this.nome = nome;
        this.endereco = endereco;
        this.carros = new ArrayList<>();
        this.vendedores = new ArrayList<>();
        this.clientes = new ArrayList<>();
        this.vendas = new ArrayList<>();
    }

    public void cadastrarCarro(Carro carro) {
        carros.add(carro);
        System.out.println("Carro cadastrado com sucesso!");
    }

    public void cadastrarVendedor(Vendedor vendedor) {
        vendedores.add(vendedor);
        System.out.println("Vendedor cadastrado com sucesso!");
    }

    public void cadastrarCliente(Cliente cliente) {
        clientes.add(cliente);
        System.out.println("Cliente cadastrado com sucesso!");
    }

    public void realizarVenda(String placaCarro, String cpfCliente, int idVendedor, 
                             String formaPagamento, double desconto) {
        Carro carro = buscarCarroPorPlaca(placaCarro);
        Cliente cliente = buscarClientePorCpf(cpfCliente);
        Vendedor vendedor = buscarVendedorPorId(idVendedor);

        if (carro == null || cliente == null || vendedor == null) {
            System.out.println("Não foi possível realizar a venda. Verifique os dados!");
            return;
        }

        if (carro.isVendido()) {
            System.out.println("Carro já vendido!");
            return;
        }

        double valorFinal = carro.calcularPrecoVenda() - desconto;
        if (cliente.isClientePremium()) {
            valorFinal *= 0.95; 
        }

        Venda venda = new Venda(carro, cliente, vendedor, valorFinal, formaPagamento);
        vendas.add(venda);
        carro.vender(desconto);
        vendedor.registrarVenda(valorFinal);
        venda.exibirRecibo();
    }

    private Carro buscarCarroPorPlaca(String placa) {
        for (Carro carro : carros) {
            if (carro.getPlaca().equals(placa)) {
                return carro;
            }
        }
        return null;
    }

    private Cliente buscarClientePorCpf(String cpf) {
        for (Cliente cliente : clientes) {
            if (cliente.getCpf().equals(cpf)) {
                return cliente;
            }
        }
        return null;
    }

    private Vendedor buscarVendedorPorId(int id) {
        for (Vendedor vendedor : vendedores) {
            if (vendedor.getIdVendedor() == id) {
                return vendedor;
            }
        }
        return null;
    }

    public void listarVendedores() {
        System.out.println("\n--- Vendedores da Concessionária ---");
        for (Vendedor v : vendedores) {
            v.exibirInformacoes();
            System.out.println("----------------------");
        }
    }

    public void listarClientes() {
        System.out.println("\n--- Clientes da Concessionária ---");
        for (Cliente c : clientes) {
            c.exibirInformacoes();
            System.out.println("----------------------");
        }
    }

    public void listarVendas() {
        System.out.println("\n--- Histórico de Vendas ---");
        for (Venda v : vendas) {
            v.exibirRecibo();
        }
    }

    //Reflexividade
     public void demonstrarReflexividade() {
        System.out.println("\n=== DEMONSTRAÇÃO DE REFLEXIVIDADE ===");
        
        for (Carro carro : carros) {
            System.out.println("\nObjeto da classe: " + carro.getClass().getSimpleName());
            
            System.out.println("É instância de Carro? " + (carro instanceof Carro));
            System.out.println("É instância de Vendavel? " + (carro instanceof Vendavel));
            
            if (carro instanceof CarroEsportivo) {
                System.out.println("Tipo específico: Carro Esportivo");
            } else if (carro instanceof CarroLuxo) {
                System.out.println("Tipo específico: Carro de Luxo");
            } else if (carro instanceof CarroEletrico) {
                System.out.println("Tipo específico: Carro Elétrico");
            }
        }
    }
}