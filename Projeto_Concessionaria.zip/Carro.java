//João Pedro Aleksandrov Lorenzetti

public abstract class Carro implements Vendavel {
    protected String modelo;
    protected String marca;
    protected int ano;
    protected double precoBase;
    protected String placa;
    protected boolean vendido;

    public Carro(String modelo, String marca, int ano, double precoBase, String placa) {
        this.modelo = modelo;
        this.marca = marca;
        this.ano = ano;
        this.precoBase = precoBase;
        this.placa = placa;
        this.vendido = false;
    }

    public abstract double calcularPrecoVenda();

    public void exibirDetalhes() {
        System.out.println("Modelo: " + modelo);
        System.out.println("Marca: " + marca);
        System.out.println("Ano: " + ano);
        System.out.println("Preço Base: R$" + precoBase);
        System.out.println("Placa: " + placa);
        System.out.println("Status: " + (vendido ? "Vendido" : "Disponível"));
    }

    public void vender() {
        this.vendido = true;
        System.out.println("Carro vendido com sucesso!");
    }

    //Sobrecarga
    public void vender(double desconto) {
        this.vendido = true;
        System.out.println("Carro vendido com desconto de R$" +desconto + "!");
    }

     public void setPrecoBase(double precoBase) {
        if (precoBase <= 0) {
            throw new IllegalArgumentException("Preço deve ser positivo!");
        }
        this.precoBase = precoBase;
    }

    public void setVendido(boolean vendido) {
        this.vendido = vendido;
    }

    public String getModelo() {
         return modelo;
     }
    public String getMarca() { 
        return marca;
     }
    public int getAno() { 
        return ano; 
    }
    public double getPrecoBase() { 
        return precoBase; 
    }
    public String getPlaca() { 
        return placa; 
    }
    public boolean isVendido() { 
        return vendido; 
    }
}